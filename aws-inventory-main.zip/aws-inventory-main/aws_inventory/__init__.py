import version

__version__ = version.__version__
